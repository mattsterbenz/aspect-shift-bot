﻿using System;

namespace NadekoBot.Modules.NSFW.Exceptions
{
}
