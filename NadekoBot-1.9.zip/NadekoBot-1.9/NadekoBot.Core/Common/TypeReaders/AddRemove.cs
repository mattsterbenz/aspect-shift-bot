﻿namespace NadekoBot.Common.TypeReaders
{
    public enum AddRemove
    {
        Add = 0,
        Rem = 1,
        Rm = 1,
    }
}
